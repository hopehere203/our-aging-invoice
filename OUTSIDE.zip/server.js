import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { subscribeRouter } from './routes/subscribe.js';
import { campaignRouter } from './routes/campaign.js';
import { webhookRouter } from './routes/webhook.js';
import { smtpRouter } from './routes/smtp.js';
import { contactsRouter } from './routes/contacts.js';
import { trackingRouter } from './routes/tracking.js';
import { templatesRouter } from './routes/templates.js';
import { sendTransactional } from './lib/mailer.js';
import { startScheduler } from './lib/scheduler.js';
import { db } from './lib/db.js'; // also initializes schema

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
app.use(express.json({ limit: '2mb' })); // higher limit to allow CSV imports in the body
app.use(express.static(path.join(__dirname, 'public'))); // serves public/index.html as the UI

app.use(subscribeRouter);
app.use(campaignRouter);
app.use(webhookRouter);
app.use(smtpRouter);
app.use(contactsRouter);
app.use(trackingRouter);
app.use(templatesRouter);

// Example transactional endpoint — call this from your app's own logic
// (e.g. after order placement), not from a campaign/list.
app.post('/send/receipt', async (req, res) => {
  const { to, order_id, amount } = req.body;
  if (!to || !order_id) return res.status(400).json({ error: 'to and order_id required' });
  try {
    await sendTransactional({
      to,
      subject: `Receipt for order #${order_id}`,
      html: `<p>Thanks for your order #${order_id}. Amount charged: $${amount}.</p>`,
      template: 'order_receipt',
    });
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Quick manual test-send used by the UI's "Send test email" button.
app.post('/api/test-send', async (req, res) => {
  const { to, cc, bcc, subject, html, attachments } = req.body;
  if (!to && !cc && !bcc) return res.status(400).json({ error: 'at least one of to/cc/bcc is required' });
  try {
    await sendTransactional({ to, cc, bcc, subject: subject || 'Test email', html: html || '<p>This is a test email.</p>', template: 'manual_test', attachments });
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get('/health', (req, res) => res.json({ ok: true }));

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Mailer running on http://localhost:${port}`);

  // A campaign left in 'sending' means the process stopped (crash, power
  // loss, sleep) mid-send — it can never legitimately still be 'sending'
  // at startup, since nothing was running a moment ago. Flag it as
  // 'interrupted' so the Campaign History tab can offer to Resume it,
  // rather than leaving it stuck forever or silently losing track of
  // which recipients were already sent to.
  const recovered = db.prepare(`UPDATE campaigns SET status = 'interrupted' WHERE status = 'sending'`).run();
  if (recovered.changes > 0) {
    console.log(`Marked ${recovered.changes} interrupted campaign(s) from a previous run — resume them from the Campaign History tab.`);
  }

  startScheduler(process.env.APP_BASE_URL || `http://localhost:${port}`);
});
