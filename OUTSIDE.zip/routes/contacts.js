import { Router } from 'express';
import { db } from '../lib/db.js';
import { bulkImport, parseRecipientInput, deleteContact } from '../lib/contacts.js';

export const contactsRouter = Router();

contactsRouter.get('/api/contacts', (req, res) => {
  const contacts = db.prepare('SELECT id, email, first_name, last_name, company, tags, status, created_at FROM contacts ORDER BY id DESC').all();
  res.json(contacts);
});

// Removes exactly one contact — for correcting a mistaken add/import.
contactsRouter.delete('/api/contacts/:id', (req, res) => {
  deleteContact(req.params.id);
  res.json({ ok: true });
});

contactsRouter.get('/api/send-log', (req, res) => {
  const log = db.prepare('SELECT * FROM send_log ORDER BY id DESC LIMIT 100').all();
  res.json(log);
});

// Accepts any of: a plain email-per-line list, a headerless "Name, email"
// list, or a proper header CSV (email,first_name,last_name,company,tags).
// Imported contacts start 'unconfirmed' unless attest_consent is explicitly
// true — see bulkImport in lib/contacts.js for what that means.
contactsRouter.post('/api/contacts/import', (req, res) => {
  const { csv, attest_consent } = req.body;
  if (!csv) return res.status(400).json({ error: 'text is required' });

  const rows = parseRecipientInput(csv);
  const result = bulkImport(rows, { attestConsent: !!attest_consent });
  res.json({ ok: true, ...result });
});
