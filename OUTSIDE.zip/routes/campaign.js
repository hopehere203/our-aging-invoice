import { Router } from 'express';
import { db } from '../lib/db.js';
import { getSubscribedContactsBySegment } from '../lib/contacts.js';
import { executeCampaign, resumeCampaign } from '../lib/scheduler.js';
import { subscribeToCampaign } from '../lib/events.js';

export const campaignRouter = Router();

function baseUrl(req) {
  return process.env.APP_BASE_URL || `${req.protocol}://${req.get('host')}`;
}

// Dry run / recipient count for a segment, without creating a campaign row.
campaignRouter.post('/campaigns/preview', (req, res) => {
  const { segment_tag } = req.body;
  const recipients = getSubscribedContactsBySegment(segment_tag || null);
  res.json({ ok: true, wouldSendTo: recipients.length });
});

// Creates a campaign. If scheduled_at is provided, it's picked up by the
// background scheduler. Otherwise sending starts immediately but is NOT
// awaited here — the response returns the campaign_id right away so the
// client can open a live SSE stream (GET /campaigns/:id/stream) and watch
// per-recipient results as they happen, instead of the request blocking
// until the whole campaign finishes.
campaignRouter.post('/campaigns/send', async (req, res) => {
  const { subject, htmlTemplate, segment_tag, scheduled_at, dryRun, attachments, cc, bcc, delivery_mode, delay_seconds } = req.body;
  if (!subject || !htmlTemplate) {
    return res.status(400).json({ error: 'subject and htmlTemplate are required' });
  }

  if (dryRun) {
    const recipients = getSubscribedContactsBySegment(segment_tag || null);
    return res.json({ ok: true, wouldSendTo: recipients.length });
  }

  const info = db.prepare(`
    INSERT INTO campaigns (subject, html, segment_tag, status, scheduled_at, attachments, cc, bcc, delivery_mode, delay_seconds)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    subject, htmlTemplate, segment_tag || null, scheduled_at ? 'scheduled' : 'draft', scheduled_at || null,
    attachments ? JSON.stringify(attachments) : null,
    cc || null, bcc || null,
    delivery_mode === 'bulk' ? 'bulk' : 'throttled',
    Number(delay_seconds) >= 0 ? Number(delay_seconds) : 2
  );

  const campaign = db.prepare('SELECT * FROM campaigns WHERE id = ?').get(info.lastInsertRowid);

  if (scheduled_at) {
    return res.json({ ok: true, scheduled: true, campaign_id: campaign.id, scheduled_at });
  }

  executeCampaign(campaign, baseUrl(req)).catch((err) => {
    db.prepare(`UPDATE campaigns SET status = 'failed' WHERE id = ?`).run(campaign.id);
    console.error(`Campaign ${campaign.id} failed:`, err);
  });

  res.json({ ok: true, live: true, campaign_id: campaign.id });
});

campaignRouter.get('/campaigns', (req, res) => {
  res.json(db.prepare('SELECT * FROM campaigns ORDER BY id DESC').all());
});

campaignRouter.get('/campaigns/:id/stats', (req, res) => {
  const campaign = db.prepare('SELECT * FROM campaigns WHERE id = ?').get(req.params.id);
  if (!campaign) return res.status(404).json({ error: 'not found' });
  const opens = db.prepare(`SELECT COUNT(DISTINCT contact_email) c FROM events WHERE campaign_id = ? AND event_type = 'open'`).get(req.params.id).c;
  const clicks = db.prepare(`SELECT COUNT(DISTINCT contact_email) c FROM events WHERE campaign_id = ? AND event_type = 'click'`).get(req.params.id).c;
  res.json({ ...campaign, unique_opens: opens, unique_clicks: clicks });
});

// Server-Sent Events stream of per-recipient send results for one campaign,
// in the form: { timestamp, email, status: 'sent'|'error', detail } as each
// one happens, followed by a final { done: true, sent, failed, total } event.
// Resumes an interrupted (crash) or failed campaign — see resumeCampaign in
// lib/scheduler.js for exactly how it decides who's safe to re-send to.
// Fire-and-forget, same as a fresh send: the client should open a new
// GET /campaigns/:id/stream right after calling this to watch it live.
campaignRouter.post('/campaigns/:id/resume', (req, res) => {
  resumeCampaign(req.params.id, baseUrl(req)).catch((err) => {
    db.prepare(`UPDATE campaigns SET status = 'failed' WHERE id = ?`).run(req.params.id);
    console.error(`Resume of campaign ${req.params.id} failed:`, err);
  });
  res.json({ ok: true, live: true, campaign_id: req.params.id });
});

campaignRouter.get('/campaigns/:id/stream', (req, res) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive',
  });
  res.write(': connected\n\n');

  const unsubscribe = subscribeToCampaign(req.params.id, (payload) => {
    res.write(`data: ${JSON.stringify(payload)}\n\n`);
    if (payload.done) {
      unsubscribe();
      res.end();
    }
  });

  req.on('close', unsubscribe);
});
