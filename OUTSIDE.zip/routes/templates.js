import { Router } from 'express';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const TEMPLATES_DIR = path.join(__dirname, '..', 'templates', 'campaigns');

// Sanitizes a template name into a safe filename — alphanumeric, dash,
// underscore only — so a crafted name can't escape TEMPLATES_DIR via
// path traversal (e.g. "../../server.js").
function safeFilename(name) {
  const cleaned = String(name || '').trim().toLowerCase().replace(/[^a-z0-9_-]+/g, '-').replace(/(^-+|-+$)/g, '');
  return cleaned || 'untitled';
}

export const templatesRouter = Router();

templatesRouter.get('/api/templates', async (req, res) => {
  try {
    await fs.mkdir(TEMPLATES_DIR, { recursive: true });
    const files = await fs.readdir(TEMPLATES_DIR);
    const names = files.filter(f => f.endsWith('.json')).map(f => f.replace(/\.json$/, ''));
    res.json({ ok: true, templates: names });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

templatesRouter.get('/api/templates/:name', async (req, res) => {
  try {
    const filePath = path.join(TEMPLATES_DIR, safeFilename(req.params.name) + '.json');
    const content = await fs.readFile(filePath, 'utf-8');
    res.json({ ok: true, template: JSON.parse(content) });
  } catch (err) {
    res.status(404).json({ ok: false, error: 'Template not found' });
  }
});

templatesRouter.post('/api/templates', async (req, res) => {
  const { name, template } = req.body;
  if (!name || !template) return res.status(400).json({ error: 'name and template are required' });
  try {
    await fs.mkdir(TEMPLATES_DIR, { recursive: true });
    const filePath = path.join(TEMPLATES_DIR, safeFilename(name) + '.json');
    await fs.writeFile(filePath, JSON.stringify(template, null, 2), 'utf-8');
    res.json({ ok: true, saved_as: safeFilename(name) });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

templatesRouter.delete('/api/templates/:name', async (req, res) => {
  try {
    const filePath = path.join(TEMPLATES_DIR, safeFilename(req.params.name) + '.json');
    await fs.unlink(filePath);
    res.json({ ok: true });
  } catch (err) {
    res.status(404).json({ ok: false, error: 'Template not found' });
  }
});
