import { Router } from 'express';
import { listProfiles, saveProfile, setActive, deleteProfile, testProfile } from '../lib/smtp.js';

export const smtpRouter = Router();

smtpRouter.get('/api/smtp', (req, res) => {
  res.json(listProfiles());
});

smtpRouter.post('/api/smtp', (req, res) => {
  const { label, host, port, secure, username, password, from_email, from_name, reply_to, max_per_minute, dkim_domain, dkim_selector, dkim_private_key } = req.body;
  if (!label || !host || !port || !username || !password || !from_email) {
    return res.status(400).json({ error: 'label, host, port, username, password, from_email are required' });
  }
  // Sender display name is required, not just defaulted from the label —
  // a From: header with no display name (just a bare address) is flagged
  // by several receiving servers/spam filters, which is almost certainly
  // what caused the earlier "mail will not go" issue.
  if (!from_name || !from_name.trim()) {
    return res.status(400).json({ error: 'From name is required — a From: header with no display name gets flagged or rejected by many receiving servers.' });
  }
  const id = saveProfile({ label, host, port, secure, username, password, from_email, from_name, reply_to, max_per_minute, dkim_domain, dkim_selector, dkim_private_key });
  res.json({ ok: true, id });
});

// Multiple profiles can be active at once (rotation pool for load-spreading + failover).
smtpRouter.post('/api/smtp/:id/activate', (req, res) => {
  setActive(req.params.id, true);
  res.json({ ok: true });
});

smtpRouter.post('/api/smtp/:id/deactivate', (req, res) => {
  setActive(req.params.id, false);
  res.json({ ok: true });
});

smtpRouter.post('/api/smtp/:id/test', async (req, res) => {
  const result = await testProfile(req.params.id);
  res.json(result);
});

smtpRouter.delete('/api/smtp/:id', (req, res) => {
  deleteProfile(req.params.id);
  res.json({ ok: true });
});
