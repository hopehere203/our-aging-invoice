import { Router } from 'express';
import { db } from '../lib/db.js';
import { markBounced, markComplained } from '../lib/contacts.js';

export const webhookRouter = Router();

// SendGrid Event Webhook: register this URL (APP_BASE_URL + /webhooks/sendgrid)
// in SendGrid > Settings > Mail Settings > Event Webhook.
// In production, verify the signature using SendGrid's ECDSA verification
// (see @sendgrid/eventwebhook) before trusting payloads.
webhookRouter.post('/webhooks/sendgrid', (req, res) => {
  const events = Array.isArray(req.body) ? req.body : [];

  for (const event of events) {
    const email = event.email;
    const type = event.event;

    db.prepare(`
      INSERT INTO events (contact_email, event_type, payload) VALUES (?, ?, ?)
    `).run(email, type, JSON.stringify(event));

    if (type === 'bounce' || type === 'dropped') {
      markBounced(email);
    } else if (type === 'spamreport') {
      markComplained(email);
    }
    // 'unsubscribe' events from SendGrid's own tracking are also logged above;
    // our own /unsubscribe/:token route is the authoritative unsubscribe path.
  }

  res.status(200).end();
});
