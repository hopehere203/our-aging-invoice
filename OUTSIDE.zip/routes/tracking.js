import { Router } from 'express';
import { db } from '../lib/db.js';

export const trackingRouter = Router();

const TRANSPARENT_PIXEL = Buffer.from(
  'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBTAA7',
  'base64'
);

function lookupToken(token) {
  return db.prepare('SELECT * FROM tracking_tokens WHERE token = ?').get(token);
}

trackingRouter.get('/track/open/:token', (req, res) => {
  const t = lookupToken(req.params.token);
  if (t) {
    db.prepare(`INSERT INTO events (contact_email, campaign_id, event_type, payload) VALUES (?, ?, 'open', ?)`)
      .run(t.contact_email, t.campaign_id, JSON.stringify({ ua: req.headers['user-agent'] || null }));
  }
  res.set('Content-Type', 'image/gif');
  res.send(TRANSPARENT_PIXEL);
});

trackingRouter.get('/track/click/:token', (req, res) => {
  const t = lookupToken(req.params.token);
  const dest = req.query.u;
  if (t && dest) {
    db.prepare(`INSERT INTO events (contact_email, campaign_id, event_type, payload) VALUES (?, ?, 'click', ?)`)
      .run(t.contact_email, t.campaign_id, JSON.stringify({ url: dest }));
  }
  if (!dest) return res.status(400).send('Missing destination URL');
  res.redirect(dest);
});
