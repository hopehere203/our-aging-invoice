import { Router } from 'express';
import { upsertContact, confirmContact, unsubscribeContact } from '../lib/contacts.js';
import { sendTransactional } from '../lib/mailer.js';

export const subscribeRouter = Router();

// Step 1: user signs up for the marketing list. Status starts as 'unconfirmed'.
subscribeRouter.post('/signup', async (req, res) => {
  const { email, first_name, last_name, company } = req.body;
  if (!email) return res.status(400).json({ error: 'email is required' });

  const contact = upsertContact({ email, first_name, last_name, company, consent_source: 'signup_form' });

  const confirmUrl = `${process.env.APP_BASE_URL}/confirm/${contact.confirm_token}`;
  await sendTransactional({
    to: contact.email,
    subject: 'Please confirm your subscription',
    html: `<p>Hi ${contact.first_name || ''}, please confirm you'd like to receive our emails:</p>
           <p><a href="${confirmUrl}">Confirm subscription</a></p>`,
    template: 'confirm_subscription',
  });

  res.json({ ok: true, message: 'Confirmation email sent' });
});

// Step 2: user clicks the confirmation link. Only now do they become 'subscribed'.
subscribeRouter.get('/confirm/:token', (req, res) => {
  const contact = confirmContact(req.params.token);
  if (!contact) return res.status(404).send('Invalid or expired confirmation link.');
  res.send(`<p>Thanks, ${contact.first_name || 'there'} — you're subscribed!</p>`);
});

// One-click unsubscribe, honored immediately, no login required.
subscribeRouter.get('/unsubscribe/:token', (req, res) => {
  const contact = unsubscribeContact(req.params.token);
  if (!contact) return res.status(404).send('Invalid unsubscribe link.');
  res.send(`<p>You've been unsubscribed and won't receive further marketing emails.</p>`);
});

// RFC 8058 one-click unsubscribe (POST), used by List-Unsubscribe-Post header
subscribeRouter.post('/unsubscribe/:token', (req, res) => {
  const contact = unsubscribeContact(req.params.token);
  if (!contact) return res.status(404).end();
  res.status(200).end();
});
